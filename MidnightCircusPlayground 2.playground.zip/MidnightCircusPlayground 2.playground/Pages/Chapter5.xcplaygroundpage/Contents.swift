import Foundation
import PlaygroundSupport
import SwiftUI
import UIKit
import CoreGraphics
import AVFoundation

let imageBackground = UIImage(named: "sfondo5.jpeg")!
let canvasDimension = CGRect(x: 0, y: 0, width: 400, height: 600)
let blackScreen = UIColor(white: 0, alpha: 1)
let blackShadow = UIColor(white: 0, alpha: 0.75)
let ringMaster = UIImage(named: "RingMaster2.png")!
let juggler = UIImage(named: "Juggler2.png")!
let tamer = UIImage(named: "Tamer2.png")!
let trapeze = UIImage(named: "Trapeze2.png")!
let scarpa = UIImage(named: "Scarpa.png")!
let ghost = UIImage(named: "Ghosts.png")!
let GhostFinale = UIImage(named: "Badendingghost.png")!
let music = Bundle.main.path(forResource: "EvilLaugh", ofType: "mp3")
let backgroundMusicPath = Bundle.main.path(forResource: "GoodNight", ofType: "mp3")
let clapEffect = Bundle.main.path(forResource: "SlowClapSoundEffect", ofType: "mp3")

var indexText2: Int = 0
var textArray2: [String] = ["","<<HA HA HA HA! Too bad… you are really wrong!>>"]

var indexText1: Int = 0
let arrayText1: [String] = [
    "",
    "Narrator: Reopening your eyes you feel your body heavier and looking down you realize your wrists are strapped to the chair with rope, tightly.",
    "Paralized with fear, you start to think this is not a dream, but, to say the least, your worst nightmare; you’re wandering if you’re even asleep at this point.",
    "*The Ring Master reappears on the stage clapping, as all the light switch on brighter than ever: his kind smile looks now more like a grin now.*",
    "Ring Master: << HA HA HA! You know, it’s not gonna be that easy to leave. Did you enjoy our little show by the way? Let me be even more specific about this circus.>>",
    "<<A curse was placed long ago on us all, we can do everything we want on the stage without fatigue or risk of getting hurt...>>",
    "<<...but we are bond to perform every night for one single person: the one who gets the nearest to the site where the circus was last placed before a huge fire destroyed it, turning everything into dust.>>",
    "*you now remember you were taking an evening walk alone and you decided to take a new path,...*",
    "*...getting lost in the woods and arriving to an empty space between the trees where the last thing you noticed before passing out were remans of a fire*",
    "Ring Master: <<Now, let’s see if you’ve been paying attention: during the show you might have noticed some prompts scattered around; among them, how many shoes where there?>>",
    "Ring Master: <<Now, let’s see if you’ve been paying attention: during the show you might have noticed some prompts scattered around; among them, how many shoes where there?>>"
]


class ChoiceViewController: UIViewController{
    let Vista = UIView()
    let backgroundView = UIImageView()
    let shadowView = UIImageView()
    let characterView = UIImageView()
    let textView = UITextView()
    let continueTextView = UITextView()
    let textBeginning = UITextView()
    let buttonView = UIButton()
    let choice1View = UIButton()
    let choice2View = UIButton()
    let choice3View = UIButton()
    let choice4View = UIButton()
    let ghostView1 = UIImageView()
    let ghostView2 = UIImageView()
    let scarpaView = UIImageView()
    let blackIntro = UIImageView()
    var backgroundMusicPlayer = AVAudioPlayer()
    var soundEffectPlayer = AVAudioPlayer()
    
    @objc func GoodEnding(){
        CreateGoodChoice()
    }
    
    @objc func BadEnding(){
        CreateBadChoice()
    }
    
    @objc func buttonFunc(){
        indexText1 += 1
        switch indexText1{
        case 1:
//            narratore
            textView.font = .italicSystemFont(ofSize: 13)
            textView.text = arrayText1[indexText1]
        case 2:
            textView.text = arrayText1[indexText1]
        case 3:
            appearingImageView(item: characterView, delayStart: 0.5, duration: 6, delayedButton: buttonView)
            setAudioEffect(effectPath: clapEffect!)
            soundEffectPlayer.setVolume(8, fadeDuration: 0.5)
            soundEffectPlayer.play()
            textView.text = arrayText1[indexText1]
        case 4:
//            ringamaster
            textView.font = .systemFont(ofSize: 13)
            textView.text = arrayText1[indexText1]
        case 5:
            textView.text = arrayText1[indexText1]
        case 6:
            textView.text = arrayText1[indexText1]
        case 7:
//            pensieri
            textView.font = .italicSystemFont(ofSize: 13)
            textView.text = arrayText1[indexText1]
        case 8:
            textView.text = arrayText1[indexText1]
        case 9:
            textView.text = arrayText1[indexText1]
        case 10:
            textView.text = arrayText1[indexText1]
            appearingButton(item: choice1View, delayStart: 0, duration: 2)
            appearingButton(item: choice2View, delayStart: 0, duration: 2)
            appearingButton(item: choice3View, delayStart: 0, duration: 2)
            appearingButton(item: choice4View, delayStart: 0, duration: 2)
            backgroundMusicPlayer.setVolume(0, fadeDuration: 2)
        default:
            break
        }
    }
    
    
    //beginning text func
     func beginnigTextappearing(item: UITextView, delayStart: Double, duration: Double){
        
         DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
             UIView.animate(withDuration: duration, animations: {
                 ()->Void in
                 self.textBeginning.layer.opacity = 0
             })
     }
     }
    
    func setAudioMusic(effectPath: String){
        do {
            try self.backgroundMusicPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    func setAudioEffect(effectPath: String){
        do {
            try self.soundEffectPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    func CreateGoodChoice(){
        let goodChoice = GoodEndingViewController()
        goodChoice.modalPresentationStyle = .fullScreen
        self.present(goodChoice, animated: true, completion: nil)
    }

    func CreateBadChoice(){
        let badChoice = BadEndingViewController()
        badChoice.modalPresentationStyle = .fullScreen
        self.present(badChoice, animated: true, completion: nil)
    }
    
    func ghostAnimation(ghost0: UIImageView){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 2, delay: 0, options: [UIView.AnimationOptions.autoreverse, UIView.AnimationOptions.repeat], animations: {
                ()->Void in
                ghost0.transform = CGAffineTransform(translationX: 0, y: 20)
            })
        }
    }
    
    func EnableButton(button: UIButton, delay: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+delay){
            UIView.animate(withDuration: 0, delay: 0, options: [], animations: {
                ()->Void in
                button.isEnabled  = true
            })
        }
    }
    
    //ANIMAZIONI
    
    func AppearDarkAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+3){
            UIView.animate(withDuration: 1, delay: 0, options: [], animations: {
                ()->Void in
                self.blackIntro.layer.opacity = 0
            })
        }
    }
    
    func pressContinueAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations: {
                ()->Void in
                self.continueTextView.layer.opacity = 0
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double, delayedButton: UIButton){
        delayedButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: delayedButton, delay: delayStart+duration)
    }
    
    func disappearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
    }
    
    func appearingButton(item: UIButton, delayStart: Double, duration: Double){
        item.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: item, delay: delayStart+duration)
    }
        
    func CreateFirstScene(){
        Vista.frame = canvasDimension
        self.Vista.addSubview(backgroundView)
        self.Vista.addSubview(shadowView)
        self.Vista.addSubview(characterView)
        self.Vista.addSubview(textView)
        self.Vista.addSubview(continueTextView)
        self.Vista.addSubview(buttonView)
        self.Vista.addSubview(choice1View)
        self.Vista.addSubview(choice2View)
        self.Vista.addSubview(choice3View)
        self.Vista.addSubview(choice4View)
        self.Vista.addSubview(blackIntro)
        self.Vista.addSubview(scarpaView)
        self.Vista.addSubview(ghostView1)
        self.Vista.addSubview(ghostView2)
        self.Vista.addSubview(textBeginning)
        
        
//      INTRO SETTINGS
        blackIntro.frame = canvasDimension
        blackIntro.backgroundColor = .black
        blackIntro.layer.zPosition = 15
        
    //        BACKGROUND SETTINGS
        backgroundView.image = imageBackground
        backgroundView.frame = canvasDimension
        backgroundView.layer.zPosition = 0
        
    //        BUTTON SETTINGS
        buttonView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        buttonView.tag = 0
        buttonView.isEnabled = false
        buttonView.addTarget(self, action: #selector(buttonFunc), for: .touchUpInside)
        buttonView.layer.cornerRadius = 20
        buttonView.layer.zPosition = 15
        
    //        VELO SETTINGS
        shadowView.frame = canvasDimension
        shadowView.backgroundColor = blackShadow
        shadowView.layer.zPosition = 3
        
    //        RINGMASTER SETTINGS
        characterView.image = ringMaster
        characterView.frame = CGRect(x: 90, y: 0, width: ringMaster.size.width/3, height: ringMaster.size.height/3)
        characterView.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        characterView.layer.shadowOpacity = 0.5
        characterView.layer.timeOffset = .zero
        characterView.layer.shadowRadius = 10
        characterView.layer.opacity = 0
        characterView.layer.zPosition = 4

//        CHOICE SETTINGS
        choice1View.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 65, width: (canvasDimension.width - 40)/2, height: canvasDimension.height/18)
        choice1View.backgroundColor = .black
        choice1View.layer.cornerRadius = 12
        choice1View.layer.borderColor = CGColor(red: 255, green: 255, blue: 255, alpha: 1)
        choice1View.layer.borderWidth = 2
        choice1View.layer.zPosition = 17
        choice1View.setTitle("10", for: .normal)
        choice1View.isEnabled = false
        choice1View.layer.opacity = 0
        choice1View.addTarget(self, action: #selector(BadEnding), for: .touchUpInside)
        
        choice2View.frame = CGRect(x: 20 + choice1View.frame.width, y: canvasDimension.maxY - canvasDimension.height/6 - 65, width: (canvasDimension.width - 40)/2, height: canvasDimension.height/18)
        choice2View.backgroundColor = .black
        choice2View.layer.cornerRadius = 12
        choice2View.layer.borderColor = CGColor(red: 255, green: 255, blue: 255, alpha: 1)
        choice2View.layer.borderWidth = 2
        choice2View.layer.zPosition = 17
        choice2View.setTitle("9", for: .normal)
        choice2View.isEnabled = false
        choice2View.layer.opacity = 0
        choice2View.addTarget(self, action: #selector(GoodEnding), for: .touchUpInside)
        
        choice3View.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 105, width: (canvasDimension.width - 40)/2, height: canvasDimension.height/18)
        choice3View.backgroundColor = .black
        choice3View.layer.cornerRadius = 12
        choice3View.layer.borderColor = CGColor(red: 255, green: 255, blue: 255, alpha: 1)
        choice3View.layer.borderWidth = 2
        choice3View.layer.zPosition = 17
        choice3View.setTitle("8", for: .normal)
        choice3View.isEnabled = false
        choice3View.layer.opacity = 0
        choice3View.addTarget(self, action: #selector(BadEnding), for: .touchUpInside)
        
        
        choice4View.frame = CGRect(x: 20 + choice1View.frame.width, y: canvasDimension.maxY - canvasDimension.height/6 - 105, width: (canvasDimension.width - 40)/2, height: canvasDimension.height/18)
        choice4View.backgroundColor = .black
        choice4View.layer.cornerRadius = 12
        choice4View.layer.borderColor = CGColor(red: 255, green: 255, blue: 255, alpha: 1)
        choice4View.layer.borderWidth = 2
        choice4View.layer.zPosition = 17
        choice4View.setTitle("7", for: .normal)
        choice4View.isEnabled = false
        choice4View.layer.opacity = 0
        choice4View.addTarget(self, action: #selector(BadEnding), for: .touchUpInside)
        
        
    //        TEXTBOX SETTINGS
        textView.backgroundColor = UIColor(white: 0, alpha: 1)
        textView.isEditable = false
        textView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        textView.layer.cornerRadius = 20
        textView.layer.borderWidth = 2
        textView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
        textView.text = ""
        textView.textColor = .white
        textView.textAlignment = .center
        textView.font = .systemFont(ofSize: 13)
        textView.layer.zPosition = 11
        
        continueTextView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
        continueTextView.frame = CGRect(x: textView.frame.maxX - 165, y: textView.frame.maxY - 30, width: 150, height: 20)
        continueTextView.text = "Press to continue"
        continueTextView.textColor = .gray
        continueTextView.font = .italicSystemFont(ofSize: 10)
        continueTextView.textAlignment = .right
        continueTextView.layer.zPosition = 12
        
        textBeginning.frame = CGRect(x: 0, y: 220, width: canvasDimension.width, height: 200)
        textBeginning.textAlignment = .center
        textBeginning.font = .boldSystemFont(ofSize: 20)
        textBeginning.backgroundColor = UIColor(white: 0, alpha: 0)
        textBeginning.textColor = .white
        textBeginning.layer.opacity = 1
        textBeginning.layer.zPosition = 21
        textBeginning.text = "CHAPTER 5"
        
//        GHOST SETTINGS
        ghostView1.frame = CGRect(x: 150, y: 150, width: ghost.size.width/3, height: ghost.size.height/3)
        ghostView1.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        ghostView1.layer.shadowOpacity = 0.5
        ghostView1.layer.shadowOffset = .zero
        ghostView1.layer.shadowRadius = 10
        ghostView1.image = ghost
        ghostView1.layer.zPosition = 3

        ghostView2.frame = CGRect(x: -100, y: 0, width: ghost.size.width/3, height: ghost.size.height/3)
        ghostView2.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        ghostView2.layer.shadowOpacity = 0.5
        ghostView2.layer.shadowOffset = .zero
        ghostView2.layer.shadowRadius = 10
        ghostView2.image = ghost
        ghostView2.layer.zPosition = 3
//        MUSICPLAYER SETTINGS
        backgroundMusicPlayer.setVolume(0, fadeDuration: 0)
        backgroundMusicPlayer.numberOfLoops = 2
    
        //SCARPA SETTINGS
        scarpaView.frame = CGRect(x: 300, y: 300, width: 150, height: 150)
        scarpaView.layer.zPosition = 1
        scarpaView.image = scarpa
        
    }

    override func loadView() {
        super.loadView()
        self.view = Vista
        CreateFirstScene()
        EnableButton(button: buttonView, delay: 5)

    }

    override func viewDidLoad() {
        super.viewDidLoad()
        AppearDarkAnimation()
        beginnigTextappearing(item: textBeginning, delayStart: 1, duration: 3)
        ghostAnimation(ghost0: ghostView1)
        ghostAnimation(ghost0: ghostView2)
        pressContinueAnimation()
        setAudioMusic(effectPath: backgroundMusicPath!)
        backgroundMusicPlayer.play()
        backgroundMusicPlayer.setVolume(1.5, fadeDuration: 3)
        
    }

    }






class GoodEndingViewController: UIViewController{
    let View = UIView()
    let background = UIImageView()
    let endingText = UITextView()
    let boxView = UITextView()
    var audioPlayer = AVAudioPlayer()
    
    
    func creditextExit(item: UITextView, delayStart: Double, duration:Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
                self.endingText.layer.opacity = 0
            })
        }
        
    }
    
    
    
 
    func creditTextEnter(item: UITextView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
                self.endingText.layer.opacity = 1
            })
        }
    }
    
    
    func introTextEnter(item: UITextView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
                self.boxView.layer.opacity = 1
            })
        }
    }
    
    
    
    
    func introTextExit(item: UITextView, delayStart: Double, duration:Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
                self.boxView.layer.opacity = 0
            })
        }
        
    }
    
    
    
    
    func GoodEndingScene(){
        View.frame = canvasDimension
        self.View.addSubview(background)
        self.View.addSubview(endingText)
        self.View.addSubview(boxView)
        
        
        boxView.backgroundColor = UIColor(white: 0, alpha: 1)
        boxView.isEditable = false
        boxView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 250, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        boxView.layer.cornerRadius = 20
        boxView.layer.borderWidth = 2
        boxView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
        boxView.text = "<<That’s right! You’ve been an attentive spectator, just as you were meant to be! For this time you’re free to go… you better run!>>\n THE END"
        boxView.layer.opacity = 0
        boxView.textColor = .white
        boxView.layer.zPosition = 3
        boxView.textAlignment = .center
        boxView.font = .italicSystemFont(ofSize: 17)
  
        
        background.layer.zPosition = 0
        background.frame = canvasDimension
        background.backgroundColor = blackScreen
        
        
        endingText.frame = CGRect(x: 0, y: canvasDimension.maxY - canvasDimension.height/6 , width: canvasDimension.width, height: canvasDimension.height/6)
        endingText.backgroundColor = UIColor(white: 0, alpha: 1)
        endingText.layer.zPosition = 2
        endingText.font = .boldSystemFont(ofSize: 12)
        endingText.text = "The Laggers\nAntonio Romano, Guendalina De Laurentis, Martina Ottaviano"
        endingText.textColor = .gray
        endingText.textAlignment = .center
        endingText.layer.opacity = 0
    
    
    
    }
    
    override func loadView() {
        super.loadView()
        self.view = View
        GoodEndingScene()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            try self.audioPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: clapEffect!) as URL)
        }catch{
            print("Player not found")
        }
        audioPlayer.setVolume( 10, fadeDuration: 0)
        audioPlayer.play()
        introTextEnter(item: boxView, delayStart: 0, duration: 2)
        introTextExit(item: boxView, delayStart: 7, duration: 2)
        creditTextEnter(item: endingText, delayStart: 9, duration: 2)
//        creditextExit(item: endingText, delayStart: 12, duration: 2)
       
      
        
    }

}


 



class BadEndingViewController: UIViewController{
    let Vista = UIView()
    let Black = UIImageView()
    let Blacksquare = UIImageView()
    let backgroundView = UIImageView()
    let characterView = UIImageView()
    let textView = UITextView()
    let continueTextView = UITextView()
    let button = UIButton()
    let text1 = UITextView()
    let endingText = UITextView()
    var musicbox = AVAudioPlayer()
    let quadrato = UIImageView()

    
    //ANIMAZIONI

    func creditextExit(item: UITextView, delayStart: Double, duration:Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
        
    }
    
    func creditTextEnter(item: UITextView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
                self.endingText.layer.opacity = 1
            })
        }
    }
    
    
    func pressContinueAnimation(){
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
                UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations: {
                    ()->Void in
                    self.continueTextView.layer.opacity = 0
                })
            }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    func disappearingBlacksquare(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
    }
    func beginningtext(item: UITextView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
                self.text1.layer.opacity = 0
            })
        }
    }
    
    func ghostanimation(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, delay:0, options: [UIView.AnimationOptions.autoreverse, UIView.AnimationOptions.repeat], animations: {
                ()->Void in
                item.center.y += 35
                
                
            })
        }
    }
    
    
    //BOTTONE
    @objc func buttonFunc(){
        indexText2 += 1
        switch indexText2 {
        case 1: textView.text = textArray2[indexText2]
            appearingImageView(item: characterView, delayStart: 1, duration: 2)
            do{try self.musicbox = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: music!)as URL)} catch{}
            musicbox.play()

        default:
            textView.text = "THE END"
//            fa sparire la textbox
            creditextExit(item: textView, delayStart: 2, duration: 2)
//            fa apparire i crediti
            creditTextEnter(item: endingText, delayStart: 4, duration: 2)
            appearingImageView(item: quadrato, delayStart: 2.2, duration: 2)
        }
    }
    

            
    func createBadEnding(){
                Vista.frame = canvasDimension
                self.Vista.addSubview(backgroundView)
                self.Vista.addSubview(characterView)
                self.Vista.addSubview(Black)
                self.Vista.addSubview(textView)
                self.Vista.addSubview(continueTextView)
                self.Vista.addSubview(button)
                self.Vista.addSubview(text1)
                self.Vista.addSubview(Blacksquare)
                self.Vista.addSubview(endingText)
                self.Vista.addSubview(quadrato)
        
        quadrato.frame = CGRect(x: 260, y: 550, width: 140, height: 50)
        quadrato.backgroundColor = .black
        quadrato.layer.zPosition = 19
        quadrato.layer.opacity = 0
        
        // BACKGROUND SETTINGS
                backgroundView.image = imageBackground
                backgroundView.frame = canvasDimension
                backgroundView.layer.zPosition = 0
            
            // BACKGROUND SETTINGS
                //Blacksquare.image = imageBackground
                Blacksquare.frame = canvasDimension
                Blacksquare.layer.zPosition = 12
                Blacksquare.layer.opacity = 1
            Blacksquare.backgroundColor = .black
            
            // BACKGROUND SETTINGS black
                
                Black.frame = canvasDimension
                Black.layer.zPosition = 1
                Black.backgroundColor = .black
                
                    
            // BUTTON SETTINGS
                    button.frame = CGRect(x: 40, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
                    button.isEnabled = true
                    button.layer.zPosition = 15
                    button.addTarget(self, action: #selector(buttonFunc), for: .touchUpInside)
            
    //CHARACTER SETTINGS
            characterView.image = GhostFinale
        characterView.frame = CGRect(x: 40, y: -50, width: GhostFinale.size.width/1.5, height: GhostFinale.size.height/1.5)
            characterView.layer.shadowColor = CGColor(
                red: 0, green: 0, blue: 0, alpha: 0.75)
            characterView.layer.shadowOpacity = 0.5
            characterView.layer.timeOffset = .zero
            characterView.layer.shadowRadius = 10
            characterView.layer.opacity = 0
            characterView.layer.zPosition = 4
        
        

    // TEXTBOX SETTINGS
            textView.backgroundColor = UIColor(white: 0, alpha: 1)
            textView.isEditable = false
            textView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
            textView.layer.cornerRadius = 20
            textView.layer.borderWidth = 2
            textView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
            textView.text = ""
            textView.textColor = .white
            textView.layer.zPosition = 10
            textView.textAlignment = .center
            textView.font = .italicSystemFont(ofSize: 13)
        
        
        // TEXTBOX SETTINGS START
                text1.backgroundColor = UIColor(white: 0, alpha: 0)
                text1.isEditable = false
                text1.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 250, width: canvasDimension.width - 40, height: canvasDimension.height/6)
               
                
                text1.textColor = .white
                text1.layer.zPosition = 18
                text1.textAlignment = .center
                text1.font = .boldSystemFont(ofSize: 15)
                text1.text = ""
      
            continueTextView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            continueTextView.frame = CGRect(x: textView.frame.maxX - 165, y: textView.frame.maxY - 30, width: 150, height: 20)
            continueTextView.text = "Press to continue"
            continueTextView.textColor = .gray
            continueTextView.font = .italicSystemFont(ofSize: 10)
            continueTextView.textAlignment = .right
            continueTextView.layer.zPosition = 12
        
        endingText.frame = CGRect(x: 0, y: canvasDimension.maxY - canvasDimension.height/6 , width: canvasDimension.width, height: canvasDimension.height/6)
        endingText.backgroundColor = UIColor(white: 0, alpha: 1)
        endingText.layer.zPosition = 2
        endingText.font = .boldSystemFont(ofSize: 12)
        endingText.text = "The Laggers\nAntonio Romano, Guendalina De Laurentis, Martina Ottaviano"
        endingText.textColor = .gray
        endingText.textAlignment = .center
        endingText.layer.opacity = 0
}
        
        override func loadView() {
            super.loadView()
            self.view = Vista
            createBadEnding()
            beginningtext(item: text1, delayStart: 1, duration: 3)
            
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        disappearingBlacksquare(item: Blacksquare, delayStart: 3, duration: 1)
        pressContinueAnimation()
        ghostanimation(item: characterView, delayStart: 0, duration: 1.5)
    }

    
}



PlaygroundPage.current.liveView = ChoiceViewController()




    
