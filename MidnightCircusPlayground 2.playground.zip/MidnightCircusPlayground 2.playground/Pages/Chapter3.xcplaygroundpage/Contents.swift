import UIKit
import PlaygroundSupport
import SwiftUI
import Foundation
import CoreGraphics
import AVFoundation

//VARIABILI GLOBALI UTILI
let imageBackground = UIImage(named: "sfondo3.jpeg")!
let Blackbackground = UIColor(white: 0, alpha: 0.75)
let backgroundMusicPath = Bundle.main.path(forResource: "GoodNight", ofType: "mp3")
let canvasDimension = CGRect(x: 0, y: 0, width: 400, height: 600)
let Tamer1 = UIImage(named: "Tamer1.png")!
let Tamer2 = UIImage(named: "Tamer2.png")!
let scarpa = UIImage(named: "Scarpa.png")!
var indexText: Int = 0
var textArray: [String] = ["","Just as the Juggler leaves the middle of the stage, the dim lights hide an other figure approaching: a young looking lady makes her appearance, holding a hula hoop in her hand and a whip tied on her waist.","Behind her a group of tigers follow, walking slowly in a straight line without any restrictions. You gasp, as by the time you notice them they in the dark they are standing less than ten feet from you, looking straight in your direction.","The lights get bright again and the Tamer introduces her performance.","Tiger Tamer: <<Don’t be scared, they don’t bite… unless I tell them to do so.>>","The tigers jump freely around the stage, passing trough the hula hoop, that you could have sworn was too small to fit, and following the faintest hints of command of their tamer.","As if they were strangely weightless, you look at them astonished as you’ve never seen anything similar before.","As they come back in their cage behind the curtains, tho, you see something very odd being given to them as a reward… something… transparent…?"]


class FirstViewController: UIViewController{
    let Vista = UIView()
    let Black = UIImageView()
    let Blacksquare = UIImageView()
    let backgroundView = UIImageView()
    let characterView = UIImageView()
    let characterView2 = UIImageView()
    let textView = UITextView()
    let continueTextView = UITextView()
    let scarpaView1 = UIImageView()
    let scarpaView2 = UIImageView()
    let scarpaView3 = UIImageView()
    let scarpaView4 = UIImageView()
    let button = UIButton()
    let text1 = UITextView()
    var backgroundMusicPlayer = AVAudioPlayer()
    
    func EnableButton(button: UIButton, delay: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+delay){
            UIView.animate(withDuration: 0, delay: 0, options: [], animations: {
                ()->Void in
                button.isEnabled  = true
            })
        }
    }
    func setAudioEffect(effectPath: String){
        do {
            try self.backgroundMusicPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    //ANIMAZIONI
    func pressContinueAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations: {
                ()->Void in
                self.continueTextView.layer.opacity = 0
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double, delayedButton: UIButton){
        delayedButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: delayedButton, delay: delayStart+duration)
    }
    
    func disappearingBlacksquare(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
    }
    func beginningtext(item: UITextView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
                self.text1.layer.opacity = 0
            })
        }
    }

//BOTTONE
    @objc func buttonFunc(){
        indexText += 1
        switch indexText {
        case 1: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
        case 2: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
            appearingImageView(item: characterView, delayStart: 1, duration: 2, delayedButton: button)
        case 3: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
        case 4: textView.text = textArray[indexText]
            textView.font = .systemFont(ofSize: 13)
        case 5: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
            appearingImageView(item: characterView2, delayStart: 2, duration: 0.5, delayedButton: button)
        case 6: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
        case 7: textView.text = textArray[indexText]
            textView.font = .italicSystemFont(ofSize: 13)
        default:
            textView.font = .systemFont(ofSize: 13)
            textView.text = "END CHAPTER 3"
            backgroundMusicPlayer.setVolume(0, fadeDuration: 3)
        }
    }
    

            
    func createThirdScene(){
                Vista.frame = canvasDimension
                self.Vista.addSubview(backgroundView)
                self.Vista.addSubview(characterView)
                self.Vista.addSubview(characterView2)
                self.Vista.addSubview(Black)
                self.Vista.addSubview(textView)
                self.Vista.addSubview(continueTextView)
                self.Vista.addSubview(scarpaView1)
                self.Vista.addSubview(scarpaView2)
                self.Vista.addSubview(scarpaView3)
                self.Vista.addSubview(scarpaView4)
                self.Vista.addSubview(button)
                self.Vista.addSubview(text1)
                self.Vista.addSubview(Blacksquare)
        
            // BACKGROUND SETTINGS
                    backgroundView.image = imageBackground
                    backgroundView.frame = canvasDimension
                    backgroundView.layer.zPosition = 0
            
            // BACKGROUND SETTINGS
                //Blacksquare.image = imageBackground
                Blacksquare.frame = canvasDimension
                Blacksquare.layer.zPosition = 15
                Blacksquare.layer.opacity = 1
            Blacksquare.backgroundColor = .black
            
            // BACKGROUND SETTINGS black
                
                Black.frame = canvasDimension
                Black.layer.zPosition = 2
                Black.backgroundColor = Blackbackground
                
                    
            // BUTTON SETTINGS
                    button.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
                    button.isEnabled = false
                    button.layer.zPosition = 15
                    button.addTarget(self, action: #selector(buttonFunc), for: .touchUpInside)
            
    //CHARACTER SETTINGS
            characterView.image = Tamer1
            characterView.frame = CGRect(x: 50, y: 0, width: Tamer1.size.width/3, height: Tamer1.size.height/3)
            characterView.layer.shadowColor = CGColor(
                red: 0, green: 0, blue: 0, alpha: 0.75)
            characterView.layer.shadowOpacity = 0.5
            characterView.layer.timeOffset = .zero
            characterView.layer.shadowRadius = 10
            characterView.layer.opacity = 0
            characterView.layer.zPosition = 4
        
        // CHARACTER2 SETTINGS
                characterView2.image = Tamer2
                characterView2.frame = CGRect(x: 50, y: 0, width: Tamer2.size.width/3, height: Tamer2.size.height/3)
                characterView2.layer.shadowColor = CGColor(
        red: 0, green: 0, blue: 0, alpha: 1)
                characterView2.layer.shadowOpacity = 0.5
                characterView2.layer.timeOffset = .zero
                characterView2.layer.shadowRadius = 10
                characterView2.layer.opacity = 0
                characterView2.layer.zPosition = 6

// TEXTBOX SETTINGS
            textView.backgroundColor = UIColor(white: 0, alpha: 1)
            textView.isEditable = false
            textView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
            textView.layer.cornerRadius = 20
            textView.layer.borderWidth = 2
            textView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
            textView.text = ""
            textView.textColor = .white
            textView.layer.zPosition = 11
            textView.textAlignment = .center
            textView.font = .italicSystemFont(ofSize: 13)
        
        
        // TEXTBOX SETTINGS START
                text1.backgroundColor = UIColor(white: 0, alpha: 0)
                text1.isEditable = false
                text1.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 250, width: canvasDimension.width - 40, height: canvasDimension.height/6)
               
                
                text1.textColor = .white
                text1.layer.zPosition = 18
                text1.textAlignment = .center
                text1.font = .boldSystemFont(ofSize: 20)
                text1.text = "CHAPTER 3"
      
            continueTextView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
    // continueTextView.backgroundColor = .black
            continueTextView.frame = CGRect(x: textView.frame.maxX - 165, y: textView.frame.maxY - 30, width: 150, height: 20)
            continueTextView.text = "Press to continue"
            continueTextView.textColor = .gray
            continueTextView.font = .italicSystemFont(ofSize: 10)
            continueTextView.textAlignment = .right
            continueTextView.layer.zPosition = 12
        
        //MUSICPLAYER SETTINGS
        backgroundMusicPlayer.numberOfLoops = 2
        backgroundMusicPlayer.setVolume(0, fadeDuration: 0)
        
        //SCARPA SETTING
        scarpaView1.frame = CGRect(x: 150, y: 0, width: 150, height: 150)
        scarpaView1.layer.zPosition = 1
        scarpaView1.image = scarpa
        scarpaView2.frame = CGRect(x: 200, y: 400, width: 150, height: 150)
        scarpaView2.layer.zPosition = 1
        scarpaView2.image = scarpa
        scarpaView3.frame = CGRect(x: 0, y: 350, width: 150, height: 150)
        scarpaView3.layer.zPosition = 1
        scarpaView3.image = scarpa
        scarpaView4.frame = CGRect(x: 200, y: 90, width: 150, height: 150)
        scarpaView4.layer.zPosition = 1
        scarpaView4.image = scarpa
}
        
        override func loadView() {
            super.loadView()
            self.view = Vista
            createThirdScene()
            beginningtext(item: text1, delayStart: 1, duration: 3)
            
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        pressContinueAnimation()
        disappearingBlacksquare(item: Blacksquare, delayStart: 3, duration: 1)
        EnableButton(button: button, delay: 4.2)
        setAudioEffect(effectPath: backgroundMusicPath!)
        backgroundMusicPlayer.play()
        backgroundMusicPlayer.setVolume(1.5, fadeDuration: 3)
        
    }

    
}


        
PlaygroundPage.current.liveView = FirstViewController()
