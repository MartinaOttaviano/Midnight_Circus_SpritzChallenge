import UIKit
import PlaygroundSupport
import SwiftUI
import Foundation
import CoreGraphics
import AVFoundation

//VARIABILI GLOBALI UTILI
let backgroundMusicPath = Bundle.main.path(forResource: "GoodNight", ofType: "mp3")
let footstepsSoundEffect = Bundle.main.path(forResource: "Footsteps", ofType: "mp3")
let spotlightSoundEffect = Bundle.main.path(forResource: "SpotlightEffect", ofType: "mp3")
let imageBackground = UIImage(named: "sfondo1.jpeg")!
let canvasDimension = CGRect(x: 0, y: 0, width: 400, height: 600)
let blackShadow = UIColor(white: 0, alpha: 0.75)
let ringMaster1 = UIImage(named: "RingMaster1.png")!
let scarpa = UIImage(named: "Scarpa.png")!
var indexText: Int = 0
var textArray: [String] = [
    "",
    "You slowly wake up in quite a peculiar scenario with no memories or hints on how you got there; while you try and get to standing, you start scanning your surroundings and images that appeared blurred are now getting more and more clear.",
    "You find yourself inside a giant striped tent, there are props scattered all around and a few empty cages in the corners.",
    "You can see no exit but you can tell it’s dark outside as there’s no light coming in, just the shimmer from a couple of candles and oil lamps placed randomly in the big room or hanging from the ceiling.",
    "The whole place seems not taken care of, if not completely abandoned, there is a thick layer of dust and spider webs everywhere.",
    "*footstep noises approaching*",
    "*footstep noises approaching*",
    "Ring Master: <<Hello there, I’m glad you’re finally awake! The Midnight Circus gives you a warm welcome! Let me explain a little…>>",
    "<<This is a rather old place, as you can see, we used to travel around bringing our breathtaking show anywhere on this continent!>>",
    "<<But recently people started to lose interest and the audience started to get slimmer and slimmer, until nobody came here anymore…>>",
    "<<But enough with this sad talk, let me introduce you to the crew!>>",
    "Narrator: With a rather puzzled look on your face, you decide to play along: this must definitely be just a weird dream and after all the whole atmosphere looks quite intriguing!",
    "A few more figures seem to suddenly materialize in front of you, and one at a time, they introduce themselves and give you a little taste of their show."
]


class FirstViewController: UIViewController{
    let Vista = UIView()
    let backgroundView = UIImageView()
    let shadowView = UIImageView()
    let characterView = UIImageView()
    let textView = UITextView()
    let luceView = UIImageView()
    let continueTextView = UITextView()
    let textBeginning = UITextView()
    let buttonView = UIButton()
    let whiteView = UIImageView()
    let eye1 = UIImageView()
    let eye2 = UIImageView()
    let scarpaView1 = UIImageView()
    let scarpaView2 = UIImageView()
    var backgroundMusicPlayer = AVAudioPlayer()
    var effectAudioPlayer = AVAudioPlayer()

    //FUNZIONI UTILI
    
    //beginning text func
     func beginnigTextappearing(item: UITextView, delayStart: Double, duration: Double){
        
         DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
             UIView.animate(withDuration: duration, animations: {
                 ()->Void in
                 self.textBeginning.layer.opacity = 0
             })
     }
     }
    
    func movingCharacter(character: UIImageView, delay: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: duration, delay: delay, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations:{
                character.center.y += 15
            })
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+8+delay){
            UIView.animate(withDuration: 1, animations:{
                character.center.y -= 15
            })
        }
    }
    
    func SpotlightAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 0.7, delay: 2, options: [], animations:{
                ()->Void in
                self.whiteView.layer.opacity = 1
            } )
        }
        setAudioEffect(effectPath: spotlightSoundEffect!)
        effectAudioPlayer.setVolume(10, fadeDuration: 0)
        effectAudioPlayer.play()
        buttonView.isEnabled = false
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 3, delay: 2, options: [], animations:{
                ()->Void in
                self.whiteView.layer.opacity = 0
                self.luceView.layer.opacity = 0
                
            } )
        }
        EnableButton(button: buttonView, delay: 5)
    }
    
    func setAudioMusic(effectPath: String){
        do {
            try self.backgroundMusicPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    func setAudioEffect(effectPath: String){
        do {
            try self.effectAudioPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    func EnableButton(button: UIButton, delay: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+delay){
            UIView.animate(withDuration: 0, delay: 0, options: [], animations: {
                ()->Void in
                button.isEnabled  = true
            })
        }
    }
    
    @objc func buttonFunc(){
        indexText += 1
        switch indexText{
        case 1:
            textView.font = .italicSystemFont(ofSize: 13)
         textView.text = textArray[indexText]

        case 2:
            textView.text = textArray[indexText]
        case 3:
            textView.text = textArray[indexText]
        case 4:
            textView.text = textArray[indexText]
        case 5:
            textView.text = textArray[indexText]
            movingCharacter(character: characterView, delay: 1, duration: 1)
            setAudioEffect(effectPath: footstepsSoundEffect!)
            effectAudioPlayer.setVolume(10, fadeDuration: 0)
            effectAudioPlayer.play()
            appearingImageView(item: characterView, delayStart: 1, duration: 8, delayedButton: buttonView)
        case 6:
            SpotlightAnimation()
        case 7:
            textView.font = .systemFont(ofSize: 13)
            textView.text = textArray[indexText]
        case 8:
            textView.text = textArray[indexText]
        case 9:
            textView.text = textArray[indexText]
        case 10:
            textView.text = textArray[indexText]
        case 11:
            textView.font = .italicSystemFont(ofSize: 13)
            textView.text = textArray[indexText]
        case 12:
            textView.text = textArray[indexText]
        default:
            textView.text = "END CHAPTER 1"
            backgroundMusicPlayer.setVolume(0, fadeDuration: 3)
        }
    }
    
    //ANIMAZIONI
    func pressContinueAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations: {
                ()->Void in
                self.continueTextView.layer.opacity = 0
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double, delayedButton: UIButton){
        delayedButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: delayedButton, delay: delayStart+duration)
    }
    
    func disappearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
    }
    
    func eyeAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1){
            UIView.animate(withDuration: 1.5, animations: {
                ()->Void in
                self.eye1.transform = CGAffineTransform(translationX: 0, y: -50)
                self.eye2.transform = CGAffineTransform(translationX: 0, y: 50)
            })
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3){
            UIView.animate(withDuration: 1.25, animations: {
                ()->Void in
                self.eye1.transform = CGAffineTransform(translationX: 0, y: 15)
                self.eye2.transform = CGAffineTransform(translationX: 0, y: -15)
            })
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5){
            UIView.animate(withDuration: 0.3, animations: {
                ()->Void in
                self.eye1.transform = CGAffineTransform(translationX: 0, y: -400)
                self.eye2.transform = CGAffineTransform(translationX: 0, y: 400)
            })
        }

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5){
            UIView.animate(withDuration: 0.1, animations: {
                ()->Void in
                self.textView.text = "!!!!!!!!!!!!!!!!!!!!!!"
                self.buttonView.isEnabled = true
            })
        }

    }
    
    func CreateFirstScene(){
        Vista.frame = canvasDimension
        self.Vista.addSubview(backgroundView)
        self.Vista.addSubview(shadowView)
        self.Vista.addSubview(characterView)
        self.Vista.addSubview(textView)
        self.Vista.addSubview(luceView)
        self.Vista.addSubview(whiteView)
        self.Vista.addSubview(continueTextView)
        self.Vista.addSubview(textBeginning)
        self.Vista.addSubview(buttonView)
        self.Vista.addSubview(scarpaView1)
        self.Vista.addSubview(scarpaView2)
        self.Vista.addSubview(eye1)
        self.Vista.addSubview(eye2)
        
        
//        BACKGROUND SETTINGS
        backgroundView.image = imageBackground
        backgroundView.frame = canvasDimension
        backgroundView.layer.zPosition = 0
        
//        SCARPE SETTINGS
        scarpaView1.image = scarpa
        scarpaView2.image = scarpa
        scarpaView1.frame = CGRect(x: 20, y: 400, width: 150, height: 150)
        scarpaView1.layer.zPosition = 2
        scarpaView2.frame = CGRect(x: 300, y: 350, width: 150, height: 150)
        scarpaView2.layer.zPosition = 2
        
//        WHITEVIEW SETTINGS
        whiteView.frame = canvasDimension
        whiteView.backgroundColor = .white
        whiteView.layer.opacity = 0
        whiteView.layer.zPosition = 9
        
//        BUTTON SETTINGS
        buttonView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        buttonView.tag = 0
        buttonView.isEnabled = false
        buttonView.addTarget(self, action: #selector(buttonFunc), for: .touchUpInside)
        buttonView.layer.cornerRadius = 20
        buttonView.layer.zPosition = 15
        
//        VELO SETTINGS
        shadowView.frame = canvasDimension
        shadowView.backgroundColor = blackShadow
        shadowView.layer.zPosition = 3
        
//        EYE EFFECT SETTINGS
        eye1.frame = CGRect(x: 0, y: -100, width: canvasDimension.width, height: canvasDimension.height/2 + 100)
        eye1.backgroundColor = .black
        eye1.layer.zPosition = 6
        
        eye2.frame = CGRect(x: 0, y: canvasDimension.midY, width: canvasDimension.width, height: canvasDimension.height/2 + 100)
        eye2.backgroundColor = .black
        eye2.layer.zPosition = 6
        
//        RINGMASTER SETTINGS
        characterView.image = ringMaster1
        characterView.frame = CGRect(x: 90, y: 0, width: ringMaster1.size.width/3, height: ringMaster1.size.height/3)
        characterView.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        characterView.layer.shadowOpacity = 0.5
        characterView.layer.timeOffset = .zero
        characterView.layer.shadowRadius = 10
        characterView.layer.opacity = 0
        characterView.layer.zPosition = 4
        
//        LUCE SETTINGS
        luceView.frame = canvasDimension
        luceView.backgroundColor = blackShadow
        luceView.layer.opacity = 0.7
        luceView.layer.zPosition = 5
        
//        TEXTBOX SETTINGS
        textView.backgroundColor = UIColor(white: 0, alpha: 1)
        textView.isEditable = false
        textView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        textView.layer.cornerRadius = 20
        textView.layer.borderWidth = 2
        textView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
        textView.text = ""
        textView.textColor = .white
        textView.textAlignment = .center
        textView.font = .systemFont(ofSize: 13)
        textView.layer.zPosition = 11
        
        continueTextView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
        continueTextView.frame = CGRect(x: textView.frame.maxX - 165, y: textView.frame.maxY - 30, width: 150, height: 20)
        continueTextView.text = "Press to continue"
        continueTextView.textColor = .gray
        continueTextView.font = .italicSystemFont(ofSize: 10)
        continueTextView.textAlignment = .right
        continueTextView.layer.zPosition = 12
        
        textBeginning.frame = CGRect(x: 0, y: 220, width: canvasDimension.width, height: 200)
        textBeginning.textAlignment = .center
        textBeginning.font = .boldSystemFont(ofSize: 20)
        textBeginning.backgroundColor = UIColor(white: 0, alpha: 0)
        textBeginning.textColor = .white
        textBeginning.layer.opacity = 1
        textBeginning.layer.zPosition = 21
        textBeginning.text = "CHAPTER 1"
        
        //AUDIOPLAYER SETTINGS
        backgroundMusicPlayer.setVolume(0, fadeDuration: 0)
        backgroundMusicPlayer.numberOfLoops = 2
    }
    
    override func loadView() {
        super.loadView()
        self.view = Vista
        CreateFirstScene()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pressContinueAnimation()
        beginnigTextappearing(item: textBeginning, delayStart: 1, duration: 3)
        eyeAnimation()
        setAudioMusic(effectPath: backgroundMusicPath!)
        backgroundMusicPlayer.play()
        backgroundMusicPlayer.setVolume(1.5, fadeDuration: 4)
    }

}
PlaygroundPage.current.liveView = FirstViewController()
