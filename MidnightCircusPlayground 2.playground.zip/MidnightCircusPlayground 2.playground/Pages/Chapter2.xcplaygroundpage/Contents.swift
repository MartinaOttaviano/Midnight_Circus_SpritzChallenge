import UIKit
import PlaygroundSupport
import SwiftUI
import Foundation
import CoreGraphics
import AVFoundation

let imageBackground1 = UIImage(named: "sfondo2.jpeg")!
let canvasDimension1 = CGRect(x: 0, y: 0, width: 400, height: 600)
let blackShadow = UIColor(white: 0, alpha: 0.75)
let juggler1 = UIImage(named: "Juggler1.png")!
let juggler2 = UIImage(named: "Juggler2.png")!
let scarpa = UIImage(named: "Scarpa.png")!
let backgroundMusicPath = Bundle.main.path(forResource: "GoodNight", ofType: "mp3")
var indexText: Int = 0
var textArray1: [String] = ["", " First out of the bunch you notice a rather robust man, holding with extreme ease an impressive amount of juggling balls and you start wandering what his performance is going to be like.", " Juggler: <<Nice to have you there, stranger. We all hope you enjoy what we prepared for you; as you heard we haven’t entertained an audience in a couple of nights, so make yourself comfortable and just look.>>"," Still a bit confused, you agree to see the exhibition, taking a seat in one of the few chairs still intact in the spectator area.", "The Juggler brings an impressive scene, working with so many props that you can’t even count them. ", "As you applaud at the end, sincerely amazed, you start noticing something a little odd around you, as if many little out-of-place details are starting to manifest themselves slowly, but you don’t think much of it as it’s common while dreaming to notice some little incongruences.", "While the the juggler is approaching the end of his turn, you notice a glimpse of something staining his hands and part of his sleeves red and something strange tight in his wrist, but you think it must be just a trick of the lights, as they got lowered quite a bit in anticipation for the next performer."]





class SecondViewController: UIViewController{
    let View1 = UIView()
    let backgroundView1 = UIImageView()
    let characterView1 = UIImageView()
    let shadowView1 = UIImageView()
    let TextView1 = UITextView()
    let continueTextView1 = UITextView()
    let Button1 = UIButton()
    let luceView = UIImageView()
    let blackSquare = UIImageView()
    let characterView2 = UIImageView()
    let characterView3 = UIImageView()
    let scarpaView = UIImageView()
    let textBeginning = UITextView()
    var backgroundMusicPlayer = AVAudioPlayer()
   
    func setAudioEffect(effectPath: String){
        do {
            try self.backgroundMusicPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
   //button behavior function: images appear with the respective text
    @objc func funcButton1(){
        indexText += 1
        switch indexText {
        case 1: TextView1.text = textArray1[indexText]
            TextView1.font = .italicSystemFont(ofSize: 13)
            appearingImageView(item: characterView1, delayStart: 1, duration: 2, delayedButton: Button1)
        case 2: TextView1.text = textArray1[indexText]
            TextView1.font = .systemFont(ofSize: 13)
        case 3: TextView1.text = textArray1[indexText]
            TextView1.font = .italicSystemFont(ofSize: 13)
        case 4: TextView1.text = textArray1[indexText]
            TextView1.font = .italicSystemFont(ofSize: 13)
        case 5: TextView1.text = textArray1[indexText]
            TextView1.font = .italicSystemFont(ofSize: 13)
        case 6: TextView1.text = textArray1[indexText]
            TextView1.font = .italicSystemFont(ofSize: 13)
            appearingImageView(item: characterView2, delayStart: 2, duration: 0.8, delayedButton: Button1)
            appearingImageView(item: characterView3, delayStart: 3, duration: 0.8)
            
        default:
            TextView1.font = .systemFont(ofSize: 13)
            TextView1.text = "END CHAPTER 2"
            backgroundMusicPlayer.setVolume(0, fadeDuration: 3)
        }
        
    }
    
   //beginning text func
    func beginnigTextappearing(item: UITextView, delayStart: Double, duration: Double){
       
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
                self.textBeginning.layer.opacity = 0
            })
    }
    }
    
    //animazione pressToContune
    func pressContinueAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations:

{
                ()->Void in
                self.continueTextView1.layer.opacity = 0
            })
        }
    }
    
    
    //beginning black disappearing
    func disappearingBlackSquare(item: UIImageView, delayStart: Double, duration: Double ){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
        
    }
    
    func EnableButton(button: UIButton, delay: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+delay){
            UIView.animate(withDuration: 0, delay: 0, options: [], animations: {
                ()->Void in
                button.isEnabled  = true
            })
        }
    }
    
    // character appearing
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double, delayedButton: UIButton){
        delayedButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: delayedButton, delay: delayStart+duration)
    }
    
    //illumunation of the character
    func disappearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 0
            })
        }
      
    }
    func createSecondScene(){
            View1.frame = canvasDimension1
            self.View1.addSubview(backgroundView1)
            self.View1.addSubview(shadowView1)
            self.View1.addSubview(characterView1)
            self.View1.addSubview(TextView1)
            self.View1.addSubview(luceView)
            self.View1.addSubview(continueTextView1)
            self.View1.addSubview(Button1)
            self.View1.addSubview(blackSquare)
            self.View1.addSubview(characterView2)
            self.View1.addSubview(characterView3)
            self.View1.addSubview(scarpaView)
            self.View1.addSubview(textBeginning)

        //beginning blackSquare setting
        blackSquare.backgroundColor = .black
            blackSquare.frame = canvasDimension1
            blackSquare.layer.zPosition = 15
            blackSquare.layer.opacity = 1
            
        // background setting
            backgroundView1.image = imageBackground1
            backgroundView1.frame = canvasDimension1
            backgroundView1.layer.zPosition = 0
            
        //button setting
            Button1.frame = CGRect(x: 20, y: canvasDimension1.maxY - canvasDimension1.height/6 - 20, width: canvasDimension1.width - 40, height: canvasDimension1.height/6)
            Button1.isEnabled = false
            Button1.layer.zPosition = 15
            Button1.addTarget(self, action: #selector(funcButton1), for: .touchUpInside)
        
         // character setting Juggler
            characterView1.image = juggler1
            characterView1.frame = CGRect(x: 90, y: 0, width: juggler1.size.width/3, height: juggler1.size.height/3)
            characterView1.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
            characterView1.layer.shadowOpacity = 0.5
            characterView1.layer.timeOffset = .zero
            characterView1.layer.shadowRadius = 10
            characterView1.layer.opacity = 0
            characterView1.layer.zPosition = 4
            
          // creepy Juggler setting
            characterView2.image = juggler2
            characterView2.frame = CGRect(x: 90, y: 0, width: juggler1.size.width/3, height: juggler2.size.height/3)
            characterView2.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
            characterView2.layer.shadowOpacity = 0.75
            characterView2.layer.timeOffset = .zero
            characterView2.layer.shadowRadius = 10
            characterView2.layer.opacity = 0
            characterView2.layer.zPosition = 4
            
         //?????è necessrio per fare il flash ?????
            characterView3.image = juggler1
            characterView3.frame = CGRect(x: 90, y: 0, width: juggler1.size.width/3, height: juggler1.size.height/3)
            characterView3.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
            characterView3.layer.shadowOpacity = 0.5
            characterView3.layer.timeOffset = .zero
            characterView3.layer.shadowRadius = 10
            characterView3.layer.opacity = 0
            characterView3.layer.zPosition = 4
        
//        shoes settings
        
            scarpaView.frame = CGRect(x: 200, y: 90, width: 150, height: 150)
            scarpaView.layer.zPosition = 1
            scarpaView.image = scarpa
        
            
         // light setting
            luceView.frame = canvasDimension1
            luceView.backgroundColor = blackShadow
            luceView.layer.opacity = 0
            luceView.layer.zPosition = 5
            
          //shadow cast setting
            shadowView1.frame = canvasDimension1
            shadowView1.backgroundColor = blackShadow
            shadowView1.layer.zPosition = 2
        
        // text setting
            TextView1.backgroundColor = UIColor(white: 0, alpha: 1)
            TextView1.isEditable = false
            TextView1.frame = CGRect(x: 20, y: canvasDimension1.maxY - canvasDimension1.height/6 - 20, width: canvasDimension1.width - 40, height: canvasDimension1.height/6)
            TextView1.layer.cornerRadius = 20
            TextView1.layer.borderWidth = 2
            TextView1.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
            TextView1.text = ""
            TextView1.textColor = .white
            TextView1.layer.zPosition = 11
            TextView1.textAlignment = .center
            TextView1.font = .italicSystemFont(ofSize: 13)
            
           //beginning text setting
            textBeginning.frame = CGRect(x: 20, y: canvasDimension1.maxY - canvasDimension1.height/6 - 250, width: canvasDimension1.width - 40, height: canvasDimension1.height/6)
            textBeginning.backgroundColor = UIColor(white: 0, alpha: 0)
            textBeginning.textColor = .white
            textBeginning.layer.zPosition = 17
            textBeginning.textAlignment = .center
            textBeginning.font = .boldSystemFont(ofSize: 20)
            textBeginning.text = "CHAPTER 2"
            
            
        // pressTo Continue setting
            continueTextView1.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
            continueTextView1.frame = CGRect(x: TextView1.frame.maxX - 165, y: TextView1.frame.maxY - 30, width: 150, height: 20)
            continueTextView1.text = "Press to continue"
            continueTextView1.textColor = .gray
            continueTextView1.font = .italicSystemFont(ofSize: 10)
            continueTextView1.textAlignment = .right
            continueTextView1.layer.zPosition = 12
        
        //musicplayer settings
        backgroundMusicPlayer.numberOfLoops = 2
        backgroundMusicPlayer.setVolume(0, fadeDuration: 0)
        }
        
        override func loadView() {
            super.loadView()
            self.view = View1
            createSecondScene()
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            pressContinueAnimation()
            beginnigTextappearing(item: textBeginning, delayStart: 1, duration: 3)
            disappearingBlackSquare(item: blackSquare, delayStart: 3, duration: 1)
            EnableButton(button: Button1, delay: 3.2)
            disappearingImageView(item: luceView, delayStart: 10, duration: 2)
            setAudioEffect(effectPath: backgroundMusicPath!)
            backgroundMusicPlayer.play()
            backgroundMusicPlayer.setVolume(1.5, fadeDuration: 3)
        }
        
        
        
    }
    PlaygroundPage.current.liveView = SecondViewController()
