//: [Previous](@previous)

import UIKit
import PlaygroundSupport
import SwiftUI
import Foundation
import CoreGraphics
import AVFoundation

let imageBackground = UIImage(named: "sfondo4.jpeg")!
let canvasDimension = CGRect(x: 0, y: 0, width: 400, height: 600)
let blackShadow = UIColor(white: 0, alpha: 0.75)
let trapeze1 = UIImage(named: "Trapeze1.png")!
let trapeze2 = UIImage(named: "Trapeze2.png")!
let scarpa = UIImage(named: "Scarpa.png")!
let backgroundMusicPath = Bundle.main.path(forResource: "GoodNight", ofType: "mp3")
var indexText: Int = 0
let arrayText: [String] = ["",
    "Narrator: as you squeeze your eyes in disbelief and lean on the side to do a double take, a group of three people covers the view to the back of the stage.",
    "You decide to brush it off, even if all of your senses are alert and are starting to tell you something is definitely not right. A light tension on your chest makes it a little harder than usual to breath.",
    "As you start sweating, failing to wake up, the voices of the trio, talking simultaneously, interrupt your thoughts.",
    "Trapeze Artists: <<You want to leave already? You’re not even stayed until the end of the show, that seems a bit rude… just relax and enjoy the last exhibition.>>",
    "Narrator: With their matching costumes, the trio uses a single trapeze to get lifted in the air,  roughly six meters from the ground.",
    "As they get into the light beam, you notice how skinny they are… impossibly skinny.",
    "But your attention gets caught by the trapeze itself, that you just now notice is straight up made out of bones.",
    "Panic begins to freeze you body, you try harder to wake up, keeping you eyes shut, but it doesn’t work."
]

class FirstViewController: UIViewController{
    let Vista = UIView()
    let backgroundView = UIImageView()
    let shadowView = UIImageView()
    let characterView = UIImageView()
    let characterCreepyView = UIImageView()
    let textView = UITextView()
    let continueTextView = UITextView()
    let textBeginning = UITextView()
    let buttonView = UIButton()
    let blackIntro = UIImageView()
    let scarpaView = UIImageView()
    var backgroundMusicPlayer = AVAudioPlayer()
    
    @objc func tapToText(){
        indexText += 1
        switch indexText{
        case 1:
            textView.font = .italicSystemFont(ofSize: 13)
            textView.text = arrayText[indexText]
        case 2:
            appearingImageView(item: characterView, delayStart: 1, duration: 3, delayedButton: buttonView)
            textView.text = arrayText[indexText]
        case 3:
            textView.text = arrayText[indexText]
        case 4:
//            Treapeze speach
            appearingImageView(item: characterCreepyView, delayStart: 0.4, duration: 3)
            textView.font = .systemFont(ofSize: 13)
            textView.text = arrayText[indexText]
        case 5:
            textView.font = .italicSystemFont(ofSize: 13)
            textView.text = arrayText[indexText]
        case 6:
            textView.text = arrayText[indexText]
        case 7:
            textView.text = arrayText[indexText]
        case 8:
            textView.text = arrayText[indexText]
        default:
            textView.font = .systemFont(ofSize: 13)
            textView.text = "END CHAPTER 4"
            backgroundMusicPlayer.setVolume(0, fadeDuration: 3)
            break
        }
    }
    
    
    //beginning text func
     func beginnigTextappearing(item: UITextView, delayStart: Double, duration: Double){
        
         DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
             UIView.animate(withDuration: duration, animations: {
                 ()->Void in
                 self.textBeginning.layer.opacity = 0
             })
     }
     }
    
    func setAudioEffect(effectPath: String){
        do {
            try self.backgroundMusicPlayer = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: effectPath) as URL)
        }catch{
            print("Player not found")
        }
    }
    
    func EnableButton(button: UIButton, delay: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+delay){
            UIView.animate(withDuration: 0, delay: 0, options: [], animations: {
                ()->Void in
                button.isEnabled  = true
            })
        }
    }
    
    func AppearDarkAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+3){
            UIView.animate(withDuration: 1, delay: 0, options: [], animations: {
                ()->Void in
                self.blackIntro.layer.opacity = 0
            })
        }
    }
    
    func pressContinueAnimation(){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()){
            UIView.animate(withDuration: 1, delay: 0.5, options: [UIView.AnimationOptions.repeat, UIView.AnimationOptions.autoreverse], animations: {
                ()->Void in
                self.continueTextView.layer.opacity = 0
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double){
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
    }
    
    func appearingImageView(item: UIImageView, delayStart: Double, duration: Double, delayedButton: UIButton){
        delayedButton.isEnabled = false
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayStart){
            UIView.animate(withDuration: duration, animations: {
                ()->Void in
                item.layer.opacity = 1
            })
        }
        EnableButton(button: delayedButton, delay: delayStart+duration)
    }
    
    func CreateFirstView(){
        Vista.frame = canvasDimension
        self.Vista.addSubview(backgroundView)
        self.Vista.addSubview(shadowView)
        self.Vista.addSubview(characterView)
        self.Vista.addSubview(characterCreepyView)
        self.Vista.addSubview(textView)
        self.Vista.addSubview(continueTextView)
        self.Vista.addSubview(scarpaView)
        self.Vista.addSubview(buttonView)
        self.Vista.addSubview(blackIntro)
        self.Vista.addSubview(textBeginning)
        
//        DISSOLVENZA INTRO SETTINGS
        blackIntro.backgroundColor = .black
        blackIntro.frame = canvasDimension
        blackIntro.layer.zPosition = 20
        
//        BACKGROUND SETTINGS
        backgroundView.image = imageBackground
        backgroundView.frame = canvasDimension
        backgroundView.layer.zPosition = 0
        
//        BUTTON SETTINGS
        buttonView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        buttonView.tag = 0
        buttonView.isEnabled = false
        buttonView.addTarget(self, action: #selector(tapToText), for: .touchUpInside)
        buttonView.layer.cornerRadius = 20
        buttonView.layer.zPosition = 15
        
//        VELO SETTINGS
        shadowView.frame = canvasDimension
        shadowView.backgroundColor = blackShadow
        shadowView.layer.zPosition = 3

//        RINGMASTER SETTINGS
        characterView.image = trapeze1
        characterView.frame = CGRect(x: 50, y: 0, width: trapeze1.size.width/3, height: trapeze1.size.height/3)
        characterView.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        characterView.layer.shadowOpacity = 0.5
        characterView.layer.timeOffset = .zero
        characterView.layer.shadowRadius = 10
        characterView.layer.opacity = 0
        characterView.layer.zPosition = 4
        
        characterCreepyView.image = trapeze2
        characterCreepyView.frame = CGRect(x: 50, y: 0, width: trapeze1.size.width/3, height: trapeze1.size.height/3)
        characterCreepyView.layer.shadowColor = CGColor(red: 0, green: 0, blue: 0, alpha: 1)
        characterCreepyView.layer.shadowOpacity = 0.5
        characterCreepyView.layer.timeOffset = .zero
        characterCreepyView.layer.shadowRadius = 10
        characterCreepyView.layer.opacity = 0
        characterCreepyView.layer.zPosition = 5
        
        
        
//        TEXTBOX SETTINGS
        textView.backgroundColor = UIColor(white: 0, alpha: 1)
        textView.isEditable = false
        textView.frame = CGRect(x: 20, y: canvasDimension.maxY - canvasDimension.height/6 - 20, width: canvasDimension.width - 40, height: canvasDimension.height/6)
        textView.layer.cornerRadius = 20
        textView.layer.borderWidth = 2
        textView.layer.borderColor = CGColor(red: 20, green: 20, blue: 20, alpha: 1)
        textView.text = ""
        textView.textColor = .white
        textView.textAlignment = .center
        textView.font = .systemFont(ofSize: 13)
        textView.layer.zPosition = 11
        
        continueTextView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0)
        continueTextView.frame = CGRect(x: textView.frame.maxX - 165, y: textView.frame.maxY - 30, width: 150, height: 20)
        continueTextView.text = "Press to continue"
        continueTextView.textColor = .gray
        continueTextView.font = .italicSystemFont(ofSize: 10)
        continueTextView.textAlignment = .right
        continueTextView.layer.zPosition = 12
        
        
        textBeginning.frame = CGRect(x: 0, y: 220, width: canvasDimension.width, height: 200)
        textBeginning.textAlignment = .center
        textBeginning.font = .boldSystemFont(ofSize: 20)
        textBeginning.backgroundColor = UIColor(white: 0, alpha: 0)
        textBeginning.textColor = .white
        textBeginning.layer.opacity = 1
        textBeginning.layer.zPosition = 21
        textBeginning.text = "CHAPTER 4"
        
        //MUSICPLAYER SETTINGS
        backgroundMusicPlayer.numberOfLoops = 2
        backgroundMusicPlayer.setVolume(0, fadeDuration: 0)
        
        //SCARPA SETTINGS
        scarpaView.frame = CGRect(x: 110, y: 220, width: 150, height: 150)
        scarpaView.layer.zPosition = 1
        scarpaView.image = scarpa
    }
    
    override func loadView() {
        self.view = Vista
        CreateFirstView()
        AppearDarkAnimation()
        EnableButton(button: buttonView, delay: 2)
        beginnigTextappearing(item: textBeginning, delayStart: 1, duration: 3)
    }
    
    override func viewDidLoad() {
        pressContinueAnimation()
        setAudioEffect(effectPath: backgroundMusicPath!)
        backgroundMusicPlayer.play()
        backgroundMusicPlayer.setVolume(1.5, fadeDuration: 3)
    }
    
}

PlaygroundPage.current.liveView = FirstViewController()
